# petutils

A collection of helper functions, testing fixtures, and generally useful stuff (relating to PET and PET BIDS).

[![run_tests](https://github.com/openneuropet/petutils/actions/workflows/run_pytest.yaml/badge.svg)](https://github.com/openneuropet/petutils/actions/workflows/run_pytest.yaml)